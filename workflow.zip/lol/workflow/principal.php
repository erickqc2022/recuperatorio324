<?php
include "conexion.inc.php";
$flujo=$_GET["flujo"];
$proceso=$_GET["proceso"];
$sql="select * from flujoproceso ";
$sql.="where Flujo='$flujo' and proceso='$proceso'";
$resultado=mysqli_query($con, $sql);
$fila=mysqli_fetch_array($resultado);
$pantalla=$fila['Pantalla'];
$pantalla.=".inc.php";
$pantallalogica=$fila['Pantalla'];
$pantallalogica.=".main.inc.php";
$procesoanterior=$proceso;
$proceso=$fila['ProcesoSiguiente'];
include $pantallalogica;
?>
<html>
<body>
	Contenido<br>
	<form action="motor.php" method="GET">
		<!--iframe src="pantalla.php"></iframe-->
		<input type="hidden" name="flujo" value="<?php echo $flujo;?>"/>
		<input type="hidden" name="proceso" value="<?php echo $proceso;?>"/>
		<input type="hidden" name="procesoanterior" value="<?php echo $procesoanterior;?>"/>
		<?php
		//echo $pantalla;
		$anterio="Anterior";
		$siguiente="Siguiente";
		echo $procesoanterior;
		if($proceso=="P4"){
			$anterio="SALIR";
			$siguiente="Enviar";
		}else{
			$anterio="Anterior";
			$siguiente="Siguiente";
		}
		if($proceso=="P5"){
			$anterio="SALIR";
			$siguiente="ELIGE MATERIA";
		}else{
			$anterio="Anterior";
			$siguiente="Siguiente";
		}
		if($proceso == 'P9'){
			$anterio="SALIR";
			$siguiente="SALIR";
		}else{
			$anterio="Anterior";
			$siguiente="Siguiente";
		}
		include $pantalla;
		?>
		<input type="submit" name="Anterior" value="<?php echo $anterio; ?>"/>
		<input type="submit" name="Siguiente" values=<?php echo $anterio; ?>/>
	</form>
</body>
</html>

