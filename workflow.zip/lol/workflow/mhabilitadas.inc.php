<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<?php
include "conexion.inc.php";
    $sql="select * from usuarios_bd.materias";
    $resultado=mysqli_query($con,$sql);
    ?>
    <table border="1">
    <tr>
        <td>INSCRITOS</td>
        <td>SIGLA</td>
        <td>HABILITADO</td>
        <td>DESCRIPSION</td>
    </tr>        
    <?php

    while($fila=mysqli_fetch_array($resultado))
    {
        echo "<tr>";
        echo "<td>".$fila["inscritos"]."</td>";
        echo "<td>".$fila["sigla"]."</td>";
        echo "<td>".$fila["habilitado"]."</td>";
        echo "<td>".$fila["descripsion"]."</td>";
        echo "</tr>";
    }
    ?>
</body>
</html>