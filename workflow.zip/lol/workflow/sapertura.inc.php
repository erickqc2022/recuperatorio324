<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>apertura</title>
<h2>Solicita la materia que desea abrir</h2><b>
</head>
<style>
    a{
        color: whitesmoke;
    }
    table{
        margin-top: 50px;
        font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
        color: blanchedalmond;
        background-color:peru;
        margin-bottom: 20px;
    }
    td{
        margin-block-start: 20px;
    }
</style>
<body>
<?php echo $nombrecompleto;?>
<table border="1">
    <tr class="id_table" id="table">
        <td id="materia">MATERIA</td>
        <td>SIGLA</td>
        <td>MARCAJE</td>
    </tr>
    <tr>
        <td><a>Analisis Matematico</a></td>
        <td><a>MAT-111</a></td>
        <td><input type="checkbox" name="mat111" value="mat111"></td>
    </tr>
    <tr>
        <td><a>Introduccion a la Progrmacion</a></td>
        <td><a>INF-111</a></td>
        <td><input type="checkbox" name="inf111" value="inf111"></td>
    </tr>
    <tr>
        <td><a>Laboratorio INF 111</a></td>
        <td><a>LAB-111</a></td>
        <td><input type="checkbox" name="lab111" value="lab111"></td>
    </tr>
    <tr>
        <td><a>Analisis Matematico II</a></td>
        <td><a>MAT-122</a></td>
        <td><input type="checkbox" name="mat122" value="mat122"></td>
    </tr>
    <tr>
        <td><a>Programacion OB</a></td>
        <td><a>INF-121</a></td>
        <td><input type="checkbox" name="inf121" value="inf121"></td>
    </tr>    
        <td><a>Organizacion de Computadoras</a></td>
        <td><a>INF-112</a></td>
        <td><input type="checkbox" name="inf112" value="inf112"></td>
    </tr>

</table>
</body>

</html>