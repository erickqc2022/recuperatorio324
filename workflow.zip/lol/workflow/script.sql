create table FlujoProceso					
(
Flujo varchar(3),
Proceso varchar(3),
ProcesoSiguiente varchar(3),
Tipo varchar(1),
Pantalla varchar(20),
Rol varchar(20)
)

create table FlujoProcesoCondicionante
(			
Flujo varchar(3),
Proceso varchar(3),
ProcesoSI varchar(3),
ProcesoNO varchar(3)
)

insert into FlujoProceso values('F1','P1','P2','I','Inicio','Alumno');
insert into FlujoProceso values('F1','P2','P3','P','Documentos','Alumno');
insert into FlujoProceso values('F1','P3','P4','P','Presentar','Alumno');
insert into FlujoProceso values('F1','P4',null,'C','AlDia','Kardex');
insert into FlujoProceso values('F1','P5',null,'F','CausaNegativa','Kardex');
insert into FlujoProceso values('F1','P6','p7','P','PagoInscripcion','Kardex');
insert into FlujoProceso values('F1','P7','p8','P','ControlDocumentos','Kardex');
insert into FlujoProceso values('F1','P8','p9','P','ElegirCarrera','Alumno');
insert into FlujoProceso values('F1','P9','p10','P','Solicitarcodigo','Alumno');
insert into FlujoProceso values('F1','P10',null,'P','CompraCarnet','Caja');


create TABLE alumno(
    id INTEGER,
    nombrecompleto varchar(20),
    coddepto integer,
    promedio INTEGER,
    cnacimiento VARCHAR(3),
    cidentidad VARCHAR(10)
)
insert into alumno values (12,'rquispe',02,51,'si','1233');
insert into alumno values (13,'nramos',02,51,'si','1231');
insert into alumno values (11,'jaruquipa',02,51,'no','1232');
insert into alumno values (15,'eapaza',02,51,'si','1234');

create TABLE FlujoProcesoCondicionante(
    Flujo VARCHAR(3),
    Proceso VARCHAR(3),
    ProcesoSI VARCHAR(3),
    ProcesoNO VARCHAR(3)
)
insert into FlujoProcesoCondicionante values('F1','P4','P6','P5');



create TABLE usuario(
    id_m VARCHAR,
    nombrecompleto varchar(20),
    matriculah VARCHAR(3),
    cidentidad VARCHAR(10),
    rol VACHAR(10)
)
insert into usuario values (7777,'rodry quispe','si','1110','Alumno');
insert into usuario values (7778,'nataly ramos','si','1111','Alumno');
insert into usuario values (7779,'juan aruquipa','no','1112','Alumno');
insert into usuario values (7774,'edson apaza','si','1113','Alumno');
insert into usuario values (1717,'jhon loza',si,'1110','Encargado');




create TABLE materias(
    inscritos INTEGER,
    sigla varchar(20),
    habilitado VARCHAR(3),
    descripsion VARCHAR(10)
)
insert into materias values (70,'mat111','si','Analisis Matematico');
insert into materias values (40,'inf121','no','Programacion OB');
insert into materias values (50,'inf112','no','Analisis Algoritmico');
insert into materias values (35,'mat122','no','Analisis Matematico II');
insert into materias values (80,'inf111','si','Introduccion a la Programacion');





insert into FlujoProcesoSeguimiento values('F1','P1','1000','msilva','2022/04/20','10:00:00','2022/04/20','14:00:00');
insert into FlujoProcesoSeguimiento values('F1','P2','1000','msilva','2022/04/20','14:01:00','2022/04/22','10:00:00');
insert into FlujoProcesoSeguimiento values('F1','P3','1000','msilva','2022/04/22','10:01:00',null,null);
insert into FlujoProcesoSeguimiento values('F1','P1','2020','msilva','2022/04/20','10:10:00','2022/04/21','11:10:00');
insert into FlujoProcesoSeguimiento values('F1','P2','2020','msilva','2022/04/21','11:11:00',null,null);
insert into FlujoProcesoSeguimiento values('F1','P1','1010','jhuaranca','2022/04/11','09:00:00','2022/04/11','09:10:00');
insert into FlujoProcesoSeguimiento values('F1','P2','10','jhuaranca','2022/04/11','09:11:00',null,null);



create TABLE FlujoProcesoCondicionante(
    Flujo VARCHAR(3),
    Proceso varchar(3),
    ProcesoSI VARCHAR(3),
    ProcesoNO VARCHAR(3)
)
Flujo	Proceso	ProcesoSI	ProcesoNO
F1	P4	P6	P5
F1	P10	P13	P11
insert into FlujoProcesoCondicionante values('F1','P4','P6','P5');
insert into FlujoProcesoCondicionante values('F1','P10','P13','P11');