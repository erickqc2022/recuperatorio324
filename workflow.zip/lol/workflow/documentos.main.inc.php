<?php
session_start();
echo "Hola: ".$_SESSION["id"]; 
echo "<br>";
$id_matri=$_SESSION["id"];
error_reporting (E_ALL ^ E_NOTICE);
if($_SESSION["id"] == null){
    header("LOCATION: principal.php?flujo=F1&proceso=P1");
}else{
    $sql="select * from usuarios_bd.usuario where id_m='$id_matri'";
    $resultado=mysqli_query($con, $sql);
    $fila=mysqli_fetch_array($resultado);
    $nombrecompleto=$fila["nombrecompleto"];
    $id_m=$fila["id_m"];
    $cidentidad=$fila["cidentidad"];


}

?>