Documentos<br>
<input type="hidden" name="id" value=""/> <br>
Nombre Completo
<input type="text" name="nombrecompleto" value="<?php echo $nombrecompleto;?>"/> <br>
Matricula universitaria
<input type="text" name="matricula" value="<?php echo $id_m;?>"/> <br>
Carnet de identidad
<input type="text" name="cidentidad" value="<?php echo $cidentidad;?>"/> <br>
Pago CPT
<input type="text" name="cidentidad" value="<?php echo $cpt;?>"/> <br>