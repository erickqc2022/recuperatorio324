
<?php
session_start();
$check = isset($_SESSION['inf111']) ? "checked" : "unchecked";
if($check=="checked"){
    echo "INF - 111 \n\n "."<br>";
}else{
    $check1 = isset($_SESSION['inf112']) ? "checked" : "unchecked";
    if($check1=="checked"){
        echo "inf112 \n\n "."<br>";
    }else{
        $check2=isset($_SESSION['mat111']) ? "checked" : "unchecked";
        if($check2=="checked"){
            echo "mat111 \n\n "."<br>";
            
        }
    }
}
?>
