hola mundo
<form action="ninguna.php">
	<input type="text" name="txtsample"/>
	<input type="submit" name="boton" value="botonazo"/>	
</form>