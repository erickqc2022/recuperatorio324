<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>

<h1>YA ENVIO SUS DOCUMENTOS...</h1><br>
<h2>Espere a que se lo recepsionen transcurrira un tiempo se publicara las personas que tengan alguna obseravsion</h2><br>
</body>
</html>