<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>principal</title>

    <!-- Google online fonts -->
    <link href="//fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800&display=swap" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
  </head>
  <body>
<section class="w3l-header">
  <nav class="navbar navbar-expand-lg navbar-light py-3">
    <div class="container">
      <a class="navbar-brand" href="index.html"><span class="fa fa-smile-o"></span>Curso<label class="logo-view">temporada</label></a>
      <!-- if logo is image enable this   
    <a class="navbar-brand" href="#index.html">
        <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
    </a> -->
      <div class="header-right d-flex align-items-center">
        <a href="contact.html" class="btn btn-outline-dark d-none d-md-block btn-outline-style mr-4">Contactactanos</a>
        <section class="w3l-menu">
          <div class="menu-btn">
            <span class="top"></span>
            <span class="mid"></span>
            <span class="bot"></span>
          </div>
        </section>
      </div>
    </div>
  </nav>
</section>

<!-- index-block1 -->
<div class="w3l-index-block1">
  <div class="content py-5">
    <div class="container py-lg-4">
      <div class="row align-items-center">
        <div class="col-lg-5 content-left">
          <h3>Curso<br>Temporada <br>Verano 2022</h3>
          <p class="mt-3 mb-lg-5 mb-4">Inicio de inscripsiones y habilitar materias</p>
          <a href="principal.php?flujo=F1&proceso=P1" class="btn btn-primary btn-style">Inscribirse</a>
        </div>
        <div class="col-lg-7 content-photo mt-lg-0 mt-5">
          <img src="assets/images/pr.jpg" class="img-fluid" alt="main image">
        </div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
<div class="w3l-index6" id="news">
  <!-- grids block 5 -->
  <section id="grids5-block" class="py-5">
    <div class="container py-lg-3">
      <div class="heading text-center">
        <h3 class="head">Comunicados</h3>
        <p>Jornada del periodo 2/2022</p>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-6 mt-5">
          <div class="grids5-info">
            <a href="#blog-single.html"><img src="assets/images/m.jpeg" alt="" class="rounded" /></a>
            <div class="blog-info">
              <h4><a href="#blog-single.html">Materias Verano</a></h4>
              <ul class="blog-list">
                <li>
                  <p><span class="fa fa-calendar-o"></span> Jan 24, 2022</p>
                </li>
                <li>
                  <p><span class="fa fa-comments-o"></span> <strong>23</strong> comments</p>
                </li>
              </ul>
              <p>Las materias que seran de apertura en el curso de temporaada misma publica den facebook</p>
              <a href="#blog-single.html" class="btn btn-outline-secondary mt-4">Read More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mt-5">
          <div class="grids5-info">
            <a href="#blog-single.html"><img src="assets/images/p2.jpg" alt="" class="rounded" /></a>
            <div class="blog-info">
              <h4><a href="#blog-single.html">Docentes designados</a></h4>
              <ul class="blog-list">
                <li>
                  <p><span class="fa fa-calendar-o"></span> Mar 14, 2022</p>
                </li>
                <li>
                  <p><span class="fa fa-comments-o"></span> <strong>12</strong> comments</p>
                </li>
              </ul>
              <p>Lsita de docentes asignados en esta temporada</p>
              <a href="#blog-single.html" class="btn btn-outline-secondary mt-4">Read More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 offset-md-3 offset-lg-0 col-md-6 mt-5">
          <div class="grids5-info">
            <a href="#blog-single.html"><img src="assets/images/un.jpeg" alt="" class="rounded" /></a>
            <div class="blog-info">
              <h4><a href="#blog-single.html">Uninet BancoUnion CPT</a></h4>
              <ul class="blog-list">
                <li>
                  <p><span class="fa fa-calendar-o"></span> July 21, 2022</p>
                </li>
                <li>
                  <p><span class="fa fa-comments-o"></span> <strong>16</strong> comments</p>
                </li>
              </ul>
              <p>Pasos para generar el cpt, con la aplicacion uninet</p>
              <a href="#blog-single.html" class="btn btn-outline-secondary mt-4">Read More</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
    <!-- footer -->
    <footer class="w3l-footer">
      <div class="footer-29 py-5">
        <div class="container pb-lg-3">
          <div class="row footer-top-29">
            <div class="col-md-6 footer-list-29 footer-1 mt-md-4">
              <h6 class="footer-title-29">Contact Us</h6>
              <ul>
                <li>
                  <span class="fa fa-map-marker"></span>
                  <p>Av. Villazón 
                    Monoblock Central - Segundo Patio
                    Edif. Carrera de Informatica<br>Nro 1995</p>
                </li>
                <li>
                  <span class="fa fa-phone"></span>
                  <a href="tel:+44 99 555 42">   +591 (2) 244-0338 | (2) 244-0325</a></li>
                <li>
                  <span class="fa fa-envelope-open-o"></span>
                  <a href="informatica@informatica.edu.bo" class="mail">
                    informatica@informatica</a></li>
              </ul>
              <div class="main-social-footer-29">
                <a href="#facebook" class="facebook"><span class="fa fa-facebook"></span></a>
                <a href="#twitter" class="twitter"><span class="fa fa-twitter"></span></a>
                <a href="#instagram" class="instagram"><span class="fa fa-instagram"></span></a>
                <a href="#google-plus" class="google-plus"><span class="fa fa-google-plus"></span></a>
                <a href="#linkedin" class="linkedin"><span class="fa fa-linkedin"></span></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- move top -->
      <button onclick="topFunction()" id="movetop" class="bg-primary" title="Go to top">
        <span class="fa fa-angle-up"></span>
      </button>
      <script>
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function () {
          scrollFunction()
        };

        function scrollFunction() {
          if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("movetop").style.display = "block";
          } else {
            document.getElementById("movetop").style.display = "none";
          }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
          document.body.scrollTop = 0;
          document.documentElement.scrollTop = 0;
        }
      </script>
      <!-- /move top -->
    </footer>
    <!-- // footer -->

    <!-- jQuery -->
    <script src="assets/js/jquery-3.4.1.slim.min.js"></script>
    <!-- Bootstrap js -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- disable body scroll which navbar is in active -->
    <script>
      $(function () {
        $('.navbar-toggler').click(function () {
          $('body').toggleClass('noscroll');
        })
      });
    </script>
    <!-- disable body scroll which navbar is in active -->



    <script src="assets/js/owl.carousel.js"></script>
    <!-- script for teams1-->
    <script>
      $(document).ready(function () {
        $('.owl-carousel').owlCarousel({
          loop: true,
          margin: 0,
          responsiveClass: true,
          responsive: {
            0: {
              items: 1,
              nav: true
            },
            667: {
              items: 2,
              nav: true,
              margin: 20
            },
            1000: {
              items: 4,
              nav: true,
              loop: true,
              margin: 25
            }
          }
        })
      })
    </script>
    <!-- //script for teams1-->

    <script>
      $(document).ready(function () {

        var $menuBtn = $('.menu-btn');
        var $nav = $('#nav');
        var $stylebox = $('#style-box');
        var $styleli = $stylebox.find('li');

        $menuBtn.on('click', function () {
          var $this = $(this);
          var styles = $stylebox.data('styles');
          $this.toggleClass("active");
          $this.next('#nav').toggleClass("open");
          $stylebox.toggleClass(styles);
        });

        $nav.addClass('topslide');

        $styleli.on('click', function () {
          var $this = $(this);
          $this.siblings().removeClass('now');
          $this.addClass('now');
          var styles = $this.data('styles');
          $nav.removeClass();
          $nav.addClass(styles);
          $nav.siblings('#style-box').removeClass();
          $nav.siblings('#style-box').data('styles', styles);
        });
      });
    </script>

    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script>
      $(document).ready(function () {
        $('.popup-with-zoom-anim').magnificPopup({
          type: 'inline',

          fixedContentPos: false,
          fixedBgPos: true,

          overflowY: 'auto',

          closeBtnInside: true,
          preloader: false,

          midClick: true,
          removalDelay: 300,
          mainClass: 'my-mfp-zoom-in'
        });

        $('.popup-with-move-anim').magnificPopup({
          type: 'inline',

          fixedContentPos: false,
          fixedBgPos: true,

          overflowY: 'auto',

          closeBtnInside: true,
          preloader: false,

          midClick: true,
          removalDelay: 300,
          mainClass: 'my-mfp-slide-bottom'
        });
      });
    </script>

    </body>

    </html>