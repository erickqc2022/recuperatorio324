<?php
$_SESSION["inf111"]=$_GET["inf111"];
$_SESSION["inf112"]=$_GET["inf112"];
$_SESSION["mat111"]=$_GET["mat111"];
?>