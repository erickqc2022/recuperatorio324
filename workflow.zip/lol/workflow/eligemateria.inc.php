<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

    <h1>SE HA INSCRITO A LA MATERIA:</h1>
</body>
</html>

<?php
session_start();
$check = isset($_SESSION['inf111']) ? "checked" : "unchecked";
if($check=="checked"){
    echo "INTRODUCCION A LA PROGRAMACION \n\n "."<br>";
    echo "EL CPT para pagar al banco: 11101 \n\n "."<br>";
}else{
    $check1 = isset($_SESSION['inf112']) ? "checked" : "unchecked";
    if($check1=="checked"){
        echo "ORGANIZACION DE COMPUTADORAS \n\n "."<br>";
        echo "EL CPT para pagar al banco: 11102\n\n "."<br>";
    }else{
        $check2=isset($_SESSION['mat111']) ? "checked" : "unchecked";
        if($check2=="checked"){
            echo "ANALISIS MATEMATICO I \n\n "."<br>";
            echo "EL CPT para pagar al banco: 11103 \n\n "."<br>";
        }
    }
}
?>
