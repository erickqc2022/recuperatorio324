<?php
include "conexion.inc.php";
$flujo=$_GET["flujo"];
$proceso=$_GET["proceso"];
echo $proceso;
$sql="select * from flujoprocesocondicionante ";
$sql.="where Flujo='$flujo' and ProcesoSI='$proceso' and ProcesoNO='$proceso'";
$resultado=mysqli_query($con, $sql);
$fila=mysqli_fetch_array($resultado);
$procesoanterior=$proceso;
$proceso=$fila['ProcesoSiguiente'];
?>
<html>
<body>
	Contenido<br>
	<form action="motor.php" method="GET">
		<!--iframe src="pantalla.php"></iframe-->
		<input type="hidden" name="flujo" value="<?php echo $flujo;?>"/>
		<input type="hidden" name="proceso" value="<?php echo $proceso;?>"/>
		<input type="hidden" name="procesoanterior" value="<?php echo $procesoanterior;?>"/>
		<?php
		//echo $pantalla;
		$anterio="Anterior";
		$siguiente="Siguiente";
        if($procesoanterior=="P4"){
            echo $procesoanterior;
            header("Location: principal.php?flujo=F1&proceso=P6");
        }else{
            if($procesoanterior=="P10"){
                echo $procesoanterior;
                header("Location: index.php");
            }
        }

		?>
	</form>

</body>
</html>