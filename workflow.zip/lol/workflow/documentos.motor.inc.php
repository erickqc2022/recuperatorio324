<?php
session_start();
$id_m=$_GET["id_m"];
$cidentidad=$_GET["cidentidad"];
$sql="update academico.alumno set ";
$sql.="id_m='$id_m', cidentidad='$cidentidad' ";
$sql.="where id_m=".$_SESSION["id"];
$resultado=mysqli_query($con, $sql);
?>