<?php
    include "conexion.inc.php";
    session_start();
    $_SESSION["ID_usuario"]=12;
    $_SESSION["cod_usuario"]="msilva";
    $sql="select * from FlujoProcesoSeguimiento";
    $sql.=" where Usuario='".$_SESSION["cod_usuario"]."' ";
    //$sql.="and HoraFin is null";
    $resultado=mysqli_query($con,$sql);
    ?>
    <table border="1">
    <tr>
        <td>NumeroTramite</td>
        <td>Flujo</td>
        <td>Proceso</td>
        <td>Usuario</td>
        <td>Fecha</td>
        <td>Hora de Inicio</td>
        <td>Hora de Fin</td>
        <td>Config</td>
    </tr>        
    <?php

    while($fila=mysqli_fetch_array($resultado))
    {
        echo "<tr>";
        echo "<td>".$fila["NumeroTramite"]."</td>";
        echo "<td>".$fila["Flujo"]."</td>";
        echo "<td>".$fila["Proceso"]."</td>";
        echo "<td>".$fila["Usuario"]."</td>";
        echo "<td>".$fila["FechaInicio"]."</td>";
        echo "<td>".$fila["HoraInicio"]."</td>";
        echo "<td>".$fila["HoraFin"]."</td>";
        echo "<td><a href='principal.php?flujo=".$fila["Flujo"]."&proceso=".$fila["Proceso"]."'>Editar</a></td>";
        echo "</tr>";
    }
?>