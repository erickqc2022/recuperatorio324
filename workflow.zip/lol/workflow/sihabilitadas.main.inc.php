<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

    <h1>LA MATERIA SI ESTA HABILITADA</h1>

</body>
</html>

<?php
session_start();
$check = isset($_SESSION['inf111']) ? "checked" : "unchecked";
if($check=="checked"){
    echo "INF - 111 \n\n "."<b>";
}else{
    $check1 = isset($_SESSION['inf112']) ? "checked" : "unchecked";
    if($check1=="checked"){
        echo "inf112 \n\n ";
    }else{
        $check2=isset($_SESSION['mat111']) ? "checked" : "unchecked";
        if($check2=="checked"){
            echo "mat111 \n\n ";
            
        }
    }
}
?>
