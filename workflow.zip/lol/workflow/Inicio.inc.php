Inicio de flujo <br>
Introduzca su Matricula:  
<input type="text" name="id" value=""/> <br>
<?php
?>